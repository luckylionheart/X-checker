'use strict';
var _0xe9d0 = ["tabId", "attached", "1.0", "lastError", "runtime", "message", "Cannot access a chrome:// URL", "log", "Network.enable", "sendCommand", "debugger", "attach", "events", "Network.loadingFinished", "Network.getResponseBody", "requestId", '{"code":-32000,"message":"No resource with given identifier found"}', "function", "match", "body", "offerPrices", "parse", "", "var x = document.getElementsByClassName('event-summary-headline__event')[0].textContent;", "var y = document.getElementsByClassName('venue')[0].textContent;", 
"var z = document.getElementsByClassName('event-header-date')[0].textContent;", "var res = {event:x,venue:y,date:z,alert_number:''};", "res", "executeScript", "tabs", "isGeneralAdmission", "length", "keys", "removeListener", "onEvent", "detach", "onDetach", "addListener", "*://*.axs.com/*price?*", "*://*.axs.com/*sections", "requestBody", "onBeforeRequest", "webRequest", "getTargets", "onRemoved", "onSuspend"];
var result;
var resaleSections;
var event_details;
var check_attached_tabs = {};
chrome[_0xe9d0[42]][_0xe9d0[41]][_0xe9d0[37]](function callOnBeforeRequest$jscomp$0(_0x77a8x6$jscomp$0) {
var _0x77a8x7$jscomp$0 = _0x77a8x6$jscomp$0[_0xe9d0[0]];
if (_0x77a8x7$jscomp$0 == -1) {
return;
}
var _0x77a8x8$jscomp$0 = false;
if (!(_0x77a8x7$jscomp$0 in check_attached_tabs)) {
check_attached_tabs[_0x77a8x7$jscomp$0] = {};
}
if (check_attached_tabs[_0x77a8x7$jscomp$0][_0xe9d0[1]] === true) {
_0x77a8x8$jscomp$0 = true;
}
if (_0x77a8x8$jscomp$0 == false) {
chrome[_0xe9d0[10]][_0xe9d0[11]]({
tabId : _0x77a8x7$jscomp$0
}, _0xe9d0[2], function() {
if (_0xe9d0[3] in chrome[_0xe9d0[4]]) {
if (chrome[_0xe9d0[4]][_0xe9d0[3]][_0xe9d0[5]] == _0xe9d0[6]) {
return;
}
console[_0xe9d0[7]](chrome[_0xe9d0[4]][_0xe9d0[3]]);
}
chrome[_0xe9d0[10]][_0xe9d0[9]]({
tabId : _0x77a8x7$jscomp$0
}, _0xe9d0[8]);
check_attached_tabs[_0x77a8x7$jscomp$0][_0xe9d0[1]] = true;
});
if (!(_0xe9d0[12] in check_attached_tabs[_0x77a8x7$jscomp$0])) {
check_attached_tabs[_0x77a8x7$jscomp$0][_0xe9d0[12]] = {
attach : function _0x77a8x9$jscomp$0(_0x77a8xa$jscomp$0, _0x77a8xb$jscomp$0, _0x77a8xc$jscomp$0) {
if (_0x77a8x7$jscomp$0 != _0x77a8xa$jscomp$0[_0xe9d0[0]]) {
return;
}
if (_0x77a8xb$jscomp$0 == _0xe9d0[13]) {
chrome[_0xe9d0[10]][_0xe9d0[9]]({
tabId : _0x77a8xa$jscomp$0[_0xe9d0[0]]
}, _0xe9d0[14], {
"requestId" : _0x77a8xc$jscomp$0[_0xe9d0[15]]
}, function(_0x77a8xd$jscomp$0) {
if (_0xe9d0[3] in chrome[_0xe9d0[4]]) {
if (chrome[_0xe9d0[4]][_0xe9d0[3]][_0xe9d0[5]] == _0xe9d0[16]) {
return;
}
}
if (!_0x77a8xd$jscomp$0[_0xe9d0[19]][_0xe9d0[18]](_0xe9d0[17]) && _0x77a8xd$jscomp$0[_0xe9d0[19]][_0xe9d0[18]](_0xe9d0[20])) {
result = JSON[_0xe9d0[21]](_0x77a8xd$jscomp$0[_0xe9d0[19]]);
var _0x77a8xe$jscomp$0 = _0xe9d0[22];
_0x77a8xe$jscomp$0 = _0x77a8xe$jscomp$0 + _0xe9d0[23];
_0x77a8xe$jscomp$0 = _0x77a8xe$jscomp$0 + _0xe9d0[24];
_0x77a8xe$jscomp$0 = _0x77a8xe$jscomp$0 + _0xe9d0[25];
_0x77a8xe$jscomp$0 = _0x77a8xe$jscomp$0 + _0xe9d0[26];
_0x77a8xe$jscomp$0 = _0x77a8xe$jscomp$0 + _0xe9d0[27];
chrome[_0xe9d0[29]][_0xe9d0[28]](_0x77a8xa$jscomp$0[_0xe9d0[0]], {
code : _0x77a8xe$jscomp$0
}, function(_0x77a8xf$jscomp$0) {
event_details = _0x77a8xf$jscomp$0;
});
}
if (!_0x77a8xd$jscomp$0[_0xe9d0[19]][_0xe9d0[18]](_0xe9d0[17]) && _0x77a8xd$jscomp$0[_0xe9d0[19]][_0xe9d0[18]](_0xe9d0[30])) {
_0x77a8xd$jscomp$0 = JSON[_0xe9d0[21]](_0x77a8xd$jscomp$0[_0xe9d0[19]]);
if (Object[_0xe9d0[32]](_0x77a8xd$jscomp$0)[_0xe9d0[31]]) {
resaleSections = _0x77a8xd$jscomp$0;
}
}
});
}
},
detach : function(_0x77a8xa$jscomp$1, _0x77a8x10$jscomp$0) {
if (_0x77a8xa$jscomp$1[_0xe9d0[0]] in check_attached_tabs) {
chrome[_0xe9d0[10]][_0xe9d0[34]][_0xe9d0[33]](check_attached_tabs[_0x77a8xa$jscomp$1[_0xe9d0[0]]][_0xe9d0[12]][_0xe9d0[11]]);
chrome[_0xe9d0[10]][_0xe9d0[36]][_0xe9d0[33]](check_attached_tabs[_0x77a8xa$jscomp$1[_0xe9d0[0]]][_0xe9d0[12]][_0xe9d0[35]]);
delete check_attached_tabs[_0x77a8xa$jscomp$1[_0xe9d0[0]]];
}
}
};
chrome[_0xe9d0[10]][_0xe9d0[34]][_0xe9d0[37]](check_attached_tabs[_0x77a8x7$jscomp$0][_0xe9d0[12]][_0xe9d0[11]]);
chrome[_0xe9d0[10]][_0xe9d0[36]][_0xe9d0[37]](check_attached_tabs[_0x77a8x7$jscomp$0][_0xe9d0[12]][_0xe9d0[35]]);
}
}
}, {
urls : [_0xe9d0[38], _0xe9d0[39]]
}, [_0xe9d0[40]]);
chrome[_0xe9d0[29]][_0xe9d0[44]][_0xe9d0[37]](function(_0x77a8x7$jscomp$1) {
chrome[_0xe9d0[10]][_0xe9d0[43]](function(_0x77a8x11$jscomp$0) {
var _0x77a8x12$jscomp$0;
for (_0x77a8x12$jscomp$0 of _0x77a8x11$jscomp$0) {
if (_0x77a8x12$jscomp$0[_0xe9d0[0]] == _0x77a8x7$jscomp$1 && _0x77a8x12$jscomp$0[_0xe9d0[1]] == true) {
chrome[_0xe9d0[10]][_0xe9d0[35]]({
tabId : _0x77a8x7$jscomp$1
}, function() {
});
break;
}
}
});
});
chrome[_0xe9d0[4]][_0xe9d0[45]][_0xe9d0[37]](function() {
var _0x77a8x7$jscomp$2;
for (_0x77a8x7$jscomp$2 in check_attached_tabs) {
chrome[_0xe9d0[10]][_0xe9d0[35]]({
tabId : _0x77a8x7$jscomp$2
}, function() {
});
}
});