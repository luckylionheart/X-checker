var Vararray = ["", "67657446756C6C59656172", "2D", "6765744D6F6E7468", "67657444617465", "596F7572206C6963656E7365206B6579206F7220796F757220656D61696C206973206E6F7420636F72726563742E", "596F752068617665207265616368656420796F7572206C696D697420666F7220746F6461792E", "596F7572206C6963656E73652068617320657870697265642E", "6765744261636B67726F756E6450616765", "657874656E73696F6E", "68747470733A2F2F7777772E7469636B6574666C792E636F6D2F70757263686173652F73656C65637453656174732F6D61703F6576656E7449643D", "676574", "6F70656E", "726573706F6E736554797065", "6A736F6E", "6F6E6C6F6164", "726573706F6E7365", "73656374696F6E73", "3C7020636C6173733D226D742D3220702D32223E4E6F20726573706F6E73652066726F6D207777772E7469636B6574666C792E636F6D3C2F703E", "7769647468", "3238307078", "637373", "626F6479", "73656374696F6E4E616D65", "6D696E", "707269636552616E6765", "6F70656E436F756E74", "5374616E64617264", "70757368", "3C74723E3C74643E", "3C2F74643E3C74643E", "24", "6D6178", "3C2F74643E3C2F74723E", "3C6469762069643D226E682D7461626C6522207374796C653D22636F6C6F723A233030303B7A2D696E6465783A313030303B6D617267696E3A30206175746F3B70616464696E673A3570783B223E", "3C7020636C6173733D22683620706C2D33222069643D2272656D61696E223E3C2F703E", "3C64697620636C6173733D226D622D32223E3C696E7075742069643D227469636B6574666C795F7365617263682220747970653D22746578742220706C616365686F6C6465723D225365617263682E2E223E3C7370616E20636C6173733D22706C2D32222069643D227469636B6574666C795F746F74616C5F636F756E74223E203C623E546F74616C3A20", "3C2F623E3C2F7370616E3E3C2F6469763E", "3C7461626C65207374796C653D2277696474683A313030253B2220636C6173733D227461626C65207461626C652D626F726465726564222069643D227469636B6574666C795F7461626C65222063656C6C73706163696E673D2230222063656C6C70616464696E673D2230223E", "3C74686561643E", "3C74723E", "3C7468207374796C653D2277696474683A3535253B223E53656374696F6E3C2F74683E", "3C7468207374796C653D2277696474683A31353B223E4D696E3C2F74683E", "3C7468207374796C653D2277696474683A3135253B223E4D61783C2F74683E", "3C7468207374796C653D2277696474683A3135253B223E416D6F756E743C2F74683E", "3C2F74723E", "3C2F74686561643E", "3C74626F64793E", "3C2F74626F64793E", "3C2F7461626C653E", "3C2F6469763E", "3C64697620636C6173733D226C696E6B223E3C2F6469763E", "7661722078203D20646F63756D656E742E717565727953656C6563746F72416C6C28275B6974656D70726F703D6E616D655D27295B305D2E696E6E6572546578743B", "7661722079203D20646F63756D656E742E676574456C656D656E744279496428277768656E27292E6368696C6472656E5B315D2E696E6E6572546578742B2720272B646F63756D656E742E676574456C656D656E744279496428277768656E27292E6368696C6472656E5B325D2E696E6E6572546578742B27272B646F63756D656E742E676574456C656D656E744279496428277768656E27292E6368696C6472656E5B335D2E696E6E6572546578743B", "766172207A203D20646F63756D656E742E676574456C656D656E74734279436C6173734E616D6528276D696E692D6D61702D76656E75652D7469746C6527295B305D2E74657874436F6E74656E743B", "76617220726573203D207B6576656E743A782C646174653A792C76656E75653A7A7D3B", "726573", "6964", "6576656E74", "64617465", "76656E7565", "7469636B6574666C79", "687474703A2F2F7175696B7469782E636F2F7469636B65746D61737465722F7469636B65746D61737465722E706870", "504F5354", "333030", "6175746F", "68746D6C", "23726573756C74", "6B65797570", "746F4C6F77657243617365", "76616C", "696E6465784F66", "74657874", "746F67676C65", "66696C746572", "237469636B6574666C795F7461626C652074626F6479207472", "6571", "6368696C6472656E", "65616368", "237469636B6574666C795F7461626C652074626F64792074723A76697369626C65", "3C623E546F74616C3A20", "3C2F623E", "237469636B6574666C795F746F74616C5F636F756E74", "6F6E", "237469636B6574666C795F736561726368", "617363", "7461626C65", "3C703E596F752068617665203C623E", "3C2F623E205175696B436865636B73206C6566742E3C2F703E", "2372656D61696E", "3C646976207374796C653D27746578742D616C69676E3A63656E7465723B20666F6E742D73697A653A20313570783B273E596F752068617665207265616368656420796F7572206C696D697420666F7220746F6461793C2F6469763E", "616A6178", "65786563757465536372697074", "74616273", "67657453656C6563746564", "6F6E6572726F72", "4E6574776F726B206572726F722E", "73656E64", "3C7020636C6173733D22683620706C2D33223E596F752068617665203C623E", "3C64697620636C6173733D226D622D32223E3C696E7075742069643D226178735F7365617263682220747970653D22746578742220706C616365686F6C6465723D225365617263682E2E223E3C623E3C7370616E20636C6173733D22706C2D32222069643D226178735F746F74616C5F636F756E74223E546F74616C3A3C2F7370616E3E3C2F623E3C2F6469763E", "3C7461626C65207374796C653D2277696474683A313030253B2220636C6173733D227461626C65207461626C652D626F726465726564222063656C6C73706163696E673D2230222069643D226178735F7461626C65222063656C6C70616464696E673D2230223E", "3C7468207374796C653D2277696474683A3530253B223E53656374696F6E3C2F74683E", "3C7468207374796C653D2277696474683A3235253B223E50726963653C2F74683E", "3C7468207374796C653D2277696474683A3235253B223E416D6F756E743C2F74683E", "6C656E677468", "617661696C6162696C697479", "696E636C75646573", "6C6162656C", "746F4669786564", "62617365", "707269636573", "616D6F756E74", "6F6E53616C65", "3C7464207374796C653D2277696474683A3530253B666F6E742D73697A653A20313370783B223E", "3C2F74643E", "3C7464207374796C653D2277696474683A3235253B666F6E742D73697A653A20313370783B223E", "3C756C20636C6173733D226E6176206E61762D746162732220726F6C653D227461626C697374223E", "3C6C6920636C6173733D226E61762D6974656D223E", "20203C6120636C6173733D226E61762D6C696E6B206163746976652220646174612D746F67676C653D227461622220687265663D22236F6E73616C65223E4F6E53616C653C2F613E", "3C2F6C693E", "20203C6120636C6173733D226E61762D6C696E6B2220646174612D746F67676C653D227461622220687265663D2223726573616C65223E526573616C653C2F613E", "3C2F756C3E", "3C64697620636C6173733D227461622D636F6E74656E74223E", "3C6469762069643D226F6E73616C652220636C6173733D22636F6E7461696E6572207461622D70616E6520616374697665223E3C62723E", "3C6469762069643D22726573616C652220636C6173733D22636F6E7461696E6572207461622D70616E652066616465223E3C62723E", "70726963654C6576656C73", "3C74643E", "73656374696F6E4C6162656C", "746F74616C", "3C64697620636C6173733D226D622D32223E3C696E7075742069643D226178735F726573616C655F7365617263682220747970653D22746578742220706C616365686F6C6465723D225365617263682E2E223E3C623E3C7370616E20636C6173733D22706C2D32222069643D226178735F726573616C655F746F74616C5F636F756E74223E546F74616C3A20", "3C2F7370616E3E3C2F623E3C2F6469763E", "3C7461626C65207374796C653D2277696474683A313030253B2220636C6173733D227461626C65207461626C652D626F726465726564222063656C6C73706163696E673D2230222069643D226178735F726573616C655F7461626C65222063656C6C70616464696E673D2230223E", "6576656E745F64657461696C73", "236178735F7461626C652074626F6479207472", "236178735F7461626C652074626F64792074723A76697369626C65", "236178735F746F74616C5F636F756E74", "236178735F736561726368", "236178735F726573616C655F7461626C652074626F6479207472", "236178735F726573616C655F7461626C652074626F64792074723A76697369626C65", "236178735F726573616C655F746F74616C5F636F756E74", "236178735F726573616C655F736561726368", "546F74616C3A20", "617873", "3C646976207374796C653D27746578742D616C69676E3A63656E7465723B20666F6E742D73697A653A20313570783B273E596F75206D75737420656E74657220796F7572206C6963656E7365206B657920696E20457874656E73696F6E206F7074696F6E732E20506C65617365207761697420666F7220796F7572206C6963656E7365206B657920746F2062652073656E7420616E64207669736974206F757220686F7720746F207061676520666F72206675727468657220696E7374616C6C6174696F6E2067756964616E63652E3C2F6469763E", "7A6F6E65507269636573", "687474703A2F2F7175696B7469782E636F2F7469636B65746D61737465722F6576656E746D616E6167652E706870", "656D61696C", "7265636F7264", "4F4B", "3C6120687265663D27726573756C742E68746D6C27207461726765743D275F626C616E6B273E3C427574746F6E20636C6173733D2762746E2062746E2D696E666F273E547261636B657220506167653C2F427574746F6E3E3C2F613E", "2E6C696E6B", "7661722078203D20646F63756D656E742E676574456C656D656E74734279436C6173734E616D6528276576656E742D6865616465725F5F6576656E742D6E616D6527295B305D2E74657874436F6E74656E743B", "7661722079203D20646F63756D656E742E676574456C656D656E74734279436C6173734E616D6528276576656E742D6865616465725F5F6576656E742D6C6F636174696F6E27295B305D2E74657874436F6E74656E743B", "766172207A203D20646F63756D656E742E676574456C656D656E74734279436C6173734E616D6528276576656E742D6865616465725F5F6576656E742D6461746527295B305D2E74657874436F6E74656E743B", "76617220726573203D207B6576656E743A782C76656E75653A792C646174653A7A7D3B", "7661722078203D20646F63756D656E742E676574456C656D656E744279496428276172746973745F6C696E6B27292E74657874436F6E74656E743B", "7661722079203D20646F63756D656E742E676574456C656D656E744279496428276172746973745F76656E75655F6E616D6527292E74657874436F6E74656E743B", "766172207A203D20646F63756D656E742E676574456C656D656E744279496428276172746973745F6576656E745F6461746527292E74657874436F6E74656E743B", "3C7468207374796C653D2277696474683A3630253B223E53656374696F6E3C2F74683E", "3C7468207374796C653D2277696474683A3230253B2220636C6173733D2274682D736D223E4D696E3C2F74683E", "3C7468207374796C653D2277696474683A3230253B2220636C6173733D2274682D736D223E4D61783C2F74683E", "3C7468207374796C653D2277696474683A3230253B2220636C6173733D2274682D736D223E416D6F756E743C2F74683E", "3C7468207374796C653D2277696474683A3230253B223E5469636B657420547970653C2F74683E", "3C7020636C6173733D226D622D3220706C2D3220717569636B5F636865636B223E3C2F703E3C64697620636C6173733D226D622D32223E3C696E7075742069643D227072696D6172795F7365617263682220747970653D22746578742220706C616365686F6C6465723D225365617263682E2E223E3C7370616E20636C6173733D22706C2D32222069643D227072696D6172795F746F74616C223E3C2F7370616E3E3C2F6469763E3C7461626C652069643D227072696D6172795F7461626C6522207374796C653D2277696474683A313030253B2220636C6173733D227461626C65207461626C652D626F726465726564207461626C652D736D222063656C6C73706163696E673D2230222063656C6C70616464696E673D2230223E", "3C7020636C6173733D226D622D3220706C2D3220717569636B5F636865636B223E3C2F703E3C64697620636C6173733D226D622D32223E3C696E7075742069643D22726573616C655F7365617263682220747970653D22746578742220706C616365686F6C6465723D225365617263682E2E223E3C7370616E20636C6173733D22706C2D32222069643D22726573616C655F746F74616C223E3C2F7370616E3E3C2F6469763E3C7461626C652069643D22726573616C655F7461626C6522207374796C653D2277696474683A313030253B2220636C6173733D227461626C65207461626C652D626F726465726564207461626C652D736D222063656C6C73706163696E673D2230222063656C6C70616464696E673D2230223E", "6F6666657273", "696E76656E746F72795479706573", "726573616C65", "73656374696F6E", "6C697374507269636552616E6765", "636F756E74", "7072696D617279", "20203C6120636C6173733D226E61762D6C696E6B206163746976652220646174612D746F67676C653D227461622220687265663D22237072696D617279223E5072696D6172793C2F613E", "3C6469762069643D227072696D6172792220636C6173733D22636F6E7461696E6572207461622D70616E6520616374697665223E3C62723E", "7469636B65746D6173746572", "3C623E596F75206861766520", "205175696B436865636B73206C6566742E3C2F623E", "2E717569636B5F636865636B", "237072696D6172795F746F74616C", "23726573616C655F746F74616C", "237072696D6172795F7461626C652074626F6479207472", "237072696D6172795F7461626C652074626F64792074723A76697369626C65", "237072696D6172795F736561726368", "23726573616C655F7461626C652074626F6479207472", "23726573616C655F7461626C652074626F64792074723A76697369626C65", "23726573616C655F736561726368", "68747470733A2F2F73657276696365732E7469636B65746D61737465722E636F6D2F6170692F69736D64732F6576656E742F", "2F717569636B7069636B733F656D6265643D6F66666572266170696B65793D623436326F69376669633670656863646B7A6F6E793562786865266170697365637265743D7071757A706672667A377A6432796C76747A3377356474797365266C696D69743D3530303026736F72743D6C6973747072696365", "7061727365", "5F656D626564646564", "3C7020636C6173733D226D742D3220702D32223E4E6F20726573706F6E73652066726F6D207469636B65746D61737465722E636F6D3C2F703E", "6F66666572", "7469636B657454797065556E736F6C645175616C6966696572", "766970", "566970", "706C6174696E756D", "506C6174696E756D", "6F666665724964", "2F6661636574733F713D617661696C61626C652673686F773D6C697374707269636572616E676526656D6265643D6465736372697074696F6E266170696B65793D623436326F69376669633670656863646B7A6F6E793562786865266170697365637265743D7071757A706672667A377A6432796C76747A3377356474797365", "666163657473", "687474703A2F2F7175696B7469782E636F2F7469636B65746D61737465722F6C6963656E73652E7068703F6C6963656E73653D", "6C6963656E7365", "26656D61696C3D", "2663757272446174653D", "6375727244617465", "3C703E43616E206E6F742076657269667920796F75722063657274696669636174696F6E2E506C656173652074727920616761696E2E3C2F703E", "6C6F67", "3C64697620636C6173733D27726F77273E", "3C64697620636C6173733D22636F6C2D78732D313220636F6C2D313220702D32223E", "517569636B205669657720496E666F204E6F7420417661696C61626C65", "5570646174652054696D653A203C623E", "75706461746554696D65", "3C64697620636C6173733D22636F6C2D78732D3620636F6C2D3620702D32223E", "5469636B657473204C69737465643A203C623E", "746F74616C5469636B657473", "4C697374696E67733A203C623E", "746F74616C4C697374696E6773", "5469636B65747320736F6C643A203C623E", "746F74616C5469636B6574536F6C64", "5472616E73616374696F6E733A203C623E", "746F74616C5472616E73616374696F6E73", "4176657261676520536F6C64205469636B65743A203C623E", "617665726167655469636B65745072696365", "41766572616765205469636B65742050726963653A203C623E", "61766572616765", "4C6F7765737420507269636564205469636B65743A203C623E", "4869676865737420507269636564205469636B65743A203C623E", "3C6120687265663D2268747470733A2F2F70726F2E737475626875622E636F6D2F73696D7765622F73696D2F73657276696365732F7072696365616E616C797369733F6576656E7449643D", "2673656374696F6E49643D30267469636B6574547970653D5044462673706C69745175616E746974793D31267469636B65745175616E746974793D3230267469636B6574547970653D414C4C4F5726726F773D4E2F4122207461726765743D225F626C616E6B223E3C627574746F6E20636C6173733D2262746E2062746E2D696E666F20702D32207072696365496E666F20666C6F61742D7269676874223E4D6F726520496E666F726D6174696F6E3C2F627574746F6E3E3C2F613E", "3433307078", "6765745F696E666F", "74696D6557696E646F77", "64656D616E64", "6576656E745061676556696577", "7469636B65745072696365", "737570706C79", "6D656469616E", "73656E644D657373616765", "6765745F636F6F6B6965", "3B20", "73706C6974", "636F6F6B6965", "68747470733A2F2F7777772E737475626875622E636F6D2F73686170652F636174616C6F672F6576656E74732F76332F", "474554", "706572666F726D657273", "75726C", "6178732E636F6D", "726573756C74", "756E646566696E6564", "6F66666572507269636573", "616464436C617373", "726573616C6553656374696F6E73", "7469636B6574666C792E636F6D", "68747470733A2F2F7777772E7469636B6574666C792E636F6D2F70757263686173652F", "3F", "73656C6563745365617473", "69643D", "2F", "3C703E506C6561736520636865636B20796F75722063757272656E7420776562736974652055524C2E3C2F703E", "7469636B65746D61737465722E636F6D", "6C6976656E6174696F6E2E636F6D", "7469636B65746D61737465722E6361", "6C6976656E6174696F6E", "7469636B65746D61737465722D6361", "6576656E742F", "23", "737475626875622E636F6D", "3235307078", "34307078", "3C64697620636C6173733D27683620746578742D6A757374696679273E596F752063616E206E6F742072756E2074686973207363726970742E3C2F6469763E3C64697620636C6173733D27683620746578742D6A757374696679273E506C6561736520636865636B2074686520776562736974652055524C2E3C2F6469763E", "737472696E67", "7461622E75726C2073686F756C64206265206120737472696E67", "617373657274", "7175657279", "7469636B65746D61737465725F6170695F6B6579", "7469636B65746D61737465725F6170695F656D61696C", "3C64697620636C6173733D276836273E506C6561736520676F20746F20746865204F7074696F6E7320616E6420656E74657220796F7572206C6963656E73652E3C2F6469763E", "73796E63", "73746F72616765"];
for (i = 0; i < Vararray.length; i++) {

	if (i == 123) {
		Vararray[i] = '<div id="onsale" class="tab-pane active"><br>';
	} else if (i == 124) {
		Vararray[i] = '<div id="resale" class="tab-pane active"><br>';
	} else if (i == 149) {
		Vararray[i] = '';
	} else {
		Vararray[i] = hex_to_ascii(Vararray[i]);
	}


	console.log(i + "<|---|>" + Vararray[i]);
}



var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $interval, $http) {


	$scope.propertyName = 'sectionLabel';
	$scope.reverse = false;

	$scope.sortBy = function(propertyName) {
		$scope.reverse = ($scope.propertyName === propertyName) ? !$scope.reverse : false;
		$scope.propertyName = propertyName;
	};


    $scope.admin = "https://frozen-reaches-24076.herokuapp.com/axs-admin";

	$scope.resultdatadata = 0;
	$scope.loadershowfirst = 1;
	$scope.urlapi = $scope.admin;
    chrome.storage.sync.get(['Api'], function(result) {
        $("#dataAPI").val(result.Api)
        $scope.urlapi += "?apikey=" + result.Api + "&cid=" + chrome.runtime.id + "&retrieve=3";

        $http.get($scope.urlapi)
            .then(function(response) {
                if (response.data == "{'RESPONSE': 'SUCCESS'}") {
                    $scope.resultdatadata = true;
                } else if (response.data == "{'RESPONSE': 'DUPLICATE KEY'}") {
                    $scope.errormsg = "API key already in use. Please enter another API key.";
                    $scope.resultdatadata = false;
                } else {
                    $scope.resultdatadata = false;
                }
                $scope.loadershowfirst = 0;
            });

    });


	    $scope.deleteApi = function() {
        $scope.loadershowfirst = 1;
        $scope.urlapi = $scope.admin;
        chrome.storage.sync.get(['Api'], function(result) {
            $("#dataAPI").val(result.Api)
            $scope.urlapi += "?apikey=" + result.Api;
            $http.get($scope.urlapi)
                .then(function(response) {
                    $scope.resultdatadata = false;
                    $scope.loadershowfirst = 0;
                });

        });



    }


	$scope.saveApi = function() {
		value = $("#dataAPI").val();
		$scope.loadershowfirst = 1;
		chrome.storage.sync.set({
			Api: value
		}, function() {
			$scope.urlapi = "https://frozen-reaches-24076.herokuapp.com/axs-admin";
			chrome.storage.sync.get(['Api'], function(result) {

				$scope.urlapi += "?apikey=" + result.Api + "&cid=" + chrome.runtime.id + "&exec=4";


				$http.get($scope.urlapi)
                    .then(function(response) {
                        if (response.data == "{'RESPONSE': 'SUCCESS'}") {
                            $scope.resultdatadata = true;
                        } else if (response.data == "{'RESPONSE': 'DUPLICATE KEY'}") {
                            $scope.errormsg = "API key already in use. Please enter another API key.";
                            $scope.resultdatadata = false;
                        } else {
                            $scope.errormsg = "Please enter a valid API key";
                            $scope.resultdatadata = false;
                        }
                        $scope.loadershowfirst = 0;
                    });

            });
        });
    }

	$scope.pagerefresh = function() {
		chrome.tabs.query({
			active: true,
			currentWindow: true
		}, function(tabs) {
			chrome.tabs.reload(tabs[0].id);
		});
	}

	$scope.getresultdata = function(sale = 'onsale') {

		offer = (chrome["extension"]["getBackgroundPage"]().result.offerPrices);
		sectin = (chrome["extension"]["getBackgroundPage"]().resaleSections);

		$scope.activeMenu = sale;
		//console.clear();
		console.log(offer);
		console.log(sectin);
		if (sale == 'onsale') {
			//Start onsale
			$scope.b = $scope.a = [];

			for (i = 0; i < offer.length; i++) {
				pd = offer[i].zonePrices[0].priceLevels;
				//console.log(pd);
				for (j = 0; j < pd.length; j++) {
					h = {};
					h.label = pd[j].label;
					h.priceLevelID = pd[j].priceLevelID;
					h.priceLevelID = pd[j].priceLevelID;
					h.seats = pd[j].availability.amount;
					h.Price = pd[j].prices[0].base;
					h.PriceID = pd[j].prices[0].priceTypeID;
					$scope.b[$scope.b.length] = h;
				}
			}
			console.log($scope.b);
			$scope.tseats = 0;
			$scope.tprice = 0;
			$scope.c = [];
			//alert(Vararray[248], "data");
			if (sectin !== undefined) {
				console.log("undefine-not-show");
				for (key in sectin) {
					var obj = sectin[key];
					for (k = 0; k < obj.availability.prices.length; k++) {
						d = obj.availability.prices;
						g = {};
						g.sectionLabel = obj.sectionLabel;
						g.seats = d[k].amount;
						$scope.tseats = $scope.tseats + g.seats;

						g.priceLevel = d[k].priceLevel;
						g.price = "No Data";
						g.label = "No Data";
						for (l = 0; l < $scope.b.length; l++) {
							if ($scope.b[l].priceLevelID == g.priceLevel) {
								g.price = parseFloat(Number($scope.b[l].Price / 100).toFixed(2));
								$scope.tprice = (parseFloat($scope.tprice) + parseFloat(g.price)).toFixed(2);
								g.label = $scope.b[l].label;
							}
						}


						$scope.c[$scope.c.length] = g;
					}


					//end onsale
				}
			} else {
				console.log("undefine-show");
				for (i = 0; i < $scope.b.length; i++) {
					g = {};
					g.sectionLabel = $scope.b[i].label;
					g.seats = $scope.b[i].seats;
					$scope.tseats = $scope.tseats + g.seats;
					g.price = "No Data";
					g.price = parseFloat(Number($scope.b[i].Price / 100).toFixed(2));
					g.priceLevel = "No Data";
					g.label = $scope.b[i].label;
					$scope.c[$scope.c.length] = g;
				}


			}
			$scope.labels = 1;
			$scope.prices = 1;
			$scope.result = $scope.c;
		} else {
			h = [];
			for (i = 0; i < offer.length; i++) {
				for (j = 0; j < offer[i].zonePrices.length; j++) {
					if (offer[i].zonePrices[j].resalePrices != "undefined") {

						for (key in offer[i].zonePrices[j].resalePrices) {
							console.log(offer[i].zonePrices[j].resalePrices[key]);
							h[key] = key;
						}

					}
				}
			}
			console.log(h);

			$scope.labels = 0;
			$scope.prices = 0;
			//Start resale
			$scope.datas = [];
			$scope.tseats = 0;
			$scope.tprice = 0;
			$scope.d = [];

			for (key in sectin) {


				var obj = sectin[key];
				g = {};

				d = obj.availability.prices;
				for (keys in h) {
					if (obj.sectionLabel == h[keys] && obj.sectionID == null) {
						g.sectionLabel = obj.sectionLabel;
						g.seats = obj.availability.total;
						$scope.d[$scope.d.length] = g;
					}
				}
				//end onsale
			}
			$scope.result = $scope.d;

			//end resale
		}
	}

	$interval(function() {

		$scope.getresultdata($scope.activeMenu);
	}, 3);
});



var tabType = Vararray[0];
var today = new Date();
var eventId = Vararray[0];
var currentDate = today[Vararray[1]]() + Vararray[2] + today[Vararray[3]]() * 1 + 1 + Vararray[2] + today[Vararray[4]]();
var errorMsgs = [Vararray[0], Vararray[5], Vararray[6], Vararray[7]];
var background = chrome["extension"]["getBackgroundPage"]();
var background_result = [];
var total_remain_ticket = 0;
var priceLevelAry = [];
var background_resale = [];
var ticket_license = Vararray[0];
var ticket_email = Vararray[0];
var ticket_event_key = Vararray[0];
var tab;
var siteUrl = Vararray[0];
var eventUrl = Vararray[0];

function getTicketflyInfo() {
	var TicketflyInfoArr = Vararray[0];
	var TicketflyInfoEventID = Vararray[10] + eventId;
	var TicketflyInfoAjax = new XMLHttpRequest();
	TicketflyInfoAjax[Vararray[12]](Vararray[11], TicketflyInfoEventID);
	TicketflyInfoAjax[Vararray[13]] = Vararray[14];
	TicketflyInfoAjax[Vararray[15]] = function() {
		var _0x985dx15 = TicketflyInfoAjax[Vararray[16]];
		if (!_0x985dx15 || !_0x985dx15[Vararray[17]] || !_0x985dx15[Vararray[17]]) {
			TicketflyInfoArr = Vararray[18];
			$(Vararray[22])[Vararray[21]](Vararray[19], Vararray[20])
		} else {
			var _0x985dx16 = 0;
			var _0x985dx17 = Vararray[0];
			var _0x985dx18 = [];
			for (var _0x985dx19 in _0x985dx15[Vararray[17]]) {
				_0x985dx18[Vararray[28]]({
					section: _0x985dx15[Vararray[17]][_0x985dx19][Vararray[23]],
					price: _0x985dx15[Vararray[17]][_0x985dx19][Vararray[25]][Vararray[24]],
					count: _0x985dx15[Vararray[17]][_0x985dx19][Vararray[26]],
					type: Vararray[27]
				});
				_0x985dx17 += Vararray[29] + _0x985dx15[Vararray[17]][_0x985dx19][Vararray[23]] + Vararray[30] + (_0x985dx15[Vararray[17]][_0x985dx19][Vararray[25]][Vararray[24]] ? Vararray[31] + _0x985dx15[Vararray[17]][_0x985dx19][Vararray[25]][Vararray[24]] : Vararray[0]) + Vararray[30] + (_0x985dx15[Vararray[17]][_0x985dx19][Vararray[25]][Vararray[32]] ? Vararray[31] + _0x985dx15[Vararray[17]][_0x985dx19][Vararray[25]][Vararray[32]] : Vararray[0]) + Vararray[30] + _0x985dx15[Vararray[17]][_0x985dx19][Vararray[26]] + Vararray[33];
				_0x985dx16 += _0x985dx15[Vararray[17]][_0x985dx19][Vararray[26]]
			};
			TicketflyInfoArr += Vararray[34];
			TicketflyInfoArr += Vararray[35];
			TicketflyInfoArr += Vararray[36] + _0x985dx16 + Vararray[37];
			TicketflyInfoArr += Vararray[38];
			TicketflyInfoArr += Vararray[39];
			TicketflyInfoArr += Vararray[40];
			TicketflyInfoArr += Vararray[41];
			TicketflyInfoArr += Vararray[42];
			TicketflyInfoArr += Vararray[43];
			TicketflyInfoArr += Vararray[44];
			TicketflyInfoArr += Vararray[45];
			TicketflyInfoArr += Vararray[46];
			TicketflyInfoArr += Vararray[47];
			TicketflyInfoArr += _0x985dx17;
			TicketflyInfoArr += Vararray[48];
			TicketflyInfoArr += Vararray[49];
			TicketflyInfoArr += Vararray[50];
			TicketflyInfoArr += Vararray[51];
			var _0x985dx1a = Vararray[0];
			_0x985dx1a += Vararray[52];
			_0x985dx1a += Vararray[53];
			_0x985dx1a += Vararray[54];
			_0x985dx1a += Vararray[55];
			_0x985dx1a += Vararray[56];
			chrome[Vararray[93]][Vararray[94]](null, function(tab) {
				var _0x985dx1b = tab[Vararray[57]];
				chrome[Vararray[93]][Vararray[92]](_0x985dx1b, {
					code: _0x985dx1a
				}, function(_0x985dx1c) {
					var _0x985dx1d = {
						remain_seats: _0x985dx16,
						event: _0x985dx1c[0][Vararray[58]],
						date: _0x985dx1c[0][Vararray[59]],
						venue: _0x985dx1c[0][Vararray[60]],
						license: ticket_license,
						email: ticket_email,
						ticket: Vararray[61]
					};
					$[Vararray[91]]({
						url: Vararray[62],
						data: _0x985dx1d,
						type: Vararray[63],
						success: function(_0x985dx1e) {
							if (!isNaN(_0x985dx1e)) {
								$(Vararray[22])[Vararray[21]]({
									"\x6D\x61\x78\x2D\x68\x65\x69\x67\x68\x74": Vararray[64],
									"\x6F\x76\x65\x72\x66\x6C\x6F\x77": Vararray[65]
								});
								$(Vararray[67])[Vararray[66]](TicketflyInfoArr);
								saveTIcketInfo(_0x985dx1c, _0x985dx18);
								$(Vararray[84])[Vararray[83]](Vararray[68], function() {
									var _0x985dx1f = $(this)[Vararray[70]]()[Vararray[69]]();
									$(Vararray[75])[Vararray[74]](function() {
										$(this)[Vararray[73]]($(this)[Vararray[72]]()[Vararray[69]]()[Vararray[71]](_0x985dx1f) > -1)
									});
									var _0x985dx20 = 0;
									$(Vararray[79])[Vararray[78]](function() {
										$(this)[Vararray[78]](function() {
											_0x985dx20 += $(this)[Vararray[77]]()[Vararray[76]](3)[Vararray[72]]() * 1
										})
									});
									$(Vararray[82])[Vararray[66]](Vararray[80] + _0x985dx20 + Vararray[81])
								});
								$(Vararray[86]).DataTable({
									"\x6F\x72\x64\x65\x72": [
										[0, Vararray[85]]
									],
									"\x73\x65\x61\x72\x63\x68\x69\x6E\x67": false,
									"\x70\x61\x67\x69\x6E\x67": false,
									"\x69\x6E\x66\x6F": false
								});
								$(Vararray[89])[Vararray[66]](Vararray[87] + _0x985dx1e + Vararray[88])
							} else {
								error = Vararray[90];
								$(Vararray[67])[Vararray[66]](error);
								return false
							}
						}
					})
				})
			})
		}
	};
	TicketflyInfoAjax[Vararray[95]] = function() {
		errorCallback(Vararray[96])
	};
	TicketflyInfoAjax[Vararray[97]]()
}

function setAxsInfos(_0x985dx1e) {
	onsale = Vararray[0];
	onsale += Vararray[98] + _0x985dx1e + Vararray[88];
	onsale += Vararray[99];
	onsale += Vararray[100];
	onsale += Vararray[39];
	onsale += Vararray[40];
	onsale += Vararray[101];
	onsale += Vararray[102];
	onsale += Vararray[103];
	onsale += Vararray[45];
	onsale += Vararray[46];
	onsale += Vararray[47];
	var _0x985dx22 = new Array();
	var _0x985dx16 = 0;
	var _0x985dx18 = [];
	for (var _0x985dx19 = 0; _0x985dx19 < priceLevelAry[Vararray[104]]; _0x985dx19++) {
		for (var _0x985dx23 = 0; _0x985dx23 < priceLevelAry[_0x985dx19][Vararray[104]]; _0x985dx23++) {
			var _0x985dx24 = priceLevelAry[_0x985dx19][_0x985dx23][Vararray[105]][Vararray[17]];
			for (var _0x985dx25 = 0; _0x985dx25 < _0x985dx24[Vararray[104]]; _0x985dx25++) {
				if (_0x985dx22[Vararray[106]](_0x985dx24[_0x985dx25][Vararray[57]])) {
					continue
				};
				_0x985dx18[Vararray[28]]({
					section: _0x985dx24[_0x985dx25][Vararray[107]],
					price: (priceLevelAry[_0x985dx19][_0x985dx23][Vararray[110]][0][Vararray[109]] / 100)[Vararray[108]](2),
					count: _0x985dx24[_0x985dx25][Vararray[111]],
					type: Vararray[112]
				});
				onsale += Vararray[40];
				onsale += Vararray[113] + _0x985dx24[_0x985dx25][Vararray[107]] + Vararray[114];
				onsale += Vararray[115] + ((priceLevelAry[_0x985dx19][_0x985dx23][Vararray[110]][0][Vararray[109]] / 100)[Vararray[108]](2) ? Vararray[31] + (priceLevelAry[_0x985dx19][_0x985dx23][Vararray[110]][0][Vararray[109]] / 100)[Vararray[108]](2) : Vararray[0]) + Vararray[114];
				onsale += Vararray[115] + _0x985dx24[_0x985dx25][Vararray[111]] + Vararray[114];
				onsale += Vararray[45];
				_0x985dx22[Vararray[28]](_0x985dx24[_0x985dx25][Vararray[57]]);
				_0x985dx16 += _0x985dx24[_0x985dx25][Vararray[111]]
			}
		}
	};
	onsale += Vararray[48];
	onsale += Vararray[49];
	var _0x985dx17 = Vararray[0];
	_0x985dx17 += Vararray[116];
	_0x985dx17 += Vararray[117];
	_0x985dx17 += Vararray[118];
	_0x985dx17 += Vararray[119];
	_0x985dx17 += Vararray[117];
	_0x985dx17 += Vararray[120];
	_0x985dx17 += Vararray[119];
	_0x985dx17 += Vararray[121];
	_0x985dx17 += Vararray[122];
	_0x985dx17 += Vararray[123];
	_0x985dx17 += onsale;
	_0x985dx17 += Vararray[50];
	_0x985dx17 += Vararray[124];
	var _0x985dx26 = Vararray[0];
	var _0x985dx27 = 0;
	if (background_resale) {
		var _0x985dx28 = Vararray[0];
		for (var _0x985dx19 in background_resale) {
			if (background_resale[_0x985dx19][Vararray[125]] == null) {
				_0x985dx28 += Vararray[40];
				_0x985dx28 += Vararray[126] + background_resale[_0x985dx19][Vararray[127]] + Vararray[114];
				_0x985dx28 += Vararray[126] + background_resale[_0x985dx19][Vararray[105]][Vararray[128]] + Vararray[114];
				_0x985dx28 += Vararray[45];
				_0x985dx27 += background_resale[_0x985dx19][Vararray[105]][Vararray[128]]
			}
		};
		_0x985dx26 += Vararray[98] + _0x985dx1e + Vararray[88];
		_0x985dx26 += Vararray[129] + _0x985dx27 + Vararray[130];
		_0x985dx26 += Vararray[131];
		_0x985dx26 += Vararray[39];
		_0x985dx26 += Vararray[40];
		_0x985dx26 += Vararray[101];
		_0x985dx26 += Vararray[103];
		_0x985dx26 += Vararray[45];
		_0x985dx26 += Vararray[46];
		_0x985dx26 += Vararray[47];
		_0x985dx26 += _0x985dx28;
		_0x985dx26 += Vararray[48];
		_0x985dx26 += Vararray[49]
	};
	_0x985dx17 += _0x985dx26;
	_0x985dx17 += Vararray[50];
	_0x985dx17 += Vararray[50];
	_0x985dx17 += Vararray[51];
	$(Vararray[67])[Vararray[66]](_0x985dx17);
	saveTIcketInfo(background[Vararray[132]], _0x985dx18);
	$(Vararray[136])[Vararray[83]](Vararray[68], function() {
		var _0x985dx1f = $(this)[Vararray[70]]()[Vararray[69]]();
		$(Vararray[133])[Vararray[74]](function() {
			$(this)[Vararray[73]]($(this)[Vararray[72]]()[Vararray[69]]()[Vararray[71]](_0x985dx1f) > -1)
		});
		var _0x985dx20 = 0;
		$(Vararray[134])[Vararray[78]](function() {
			$(this)[Vararray[78]](function() {
				_0x985dx20 += $(this)[Vararray[77]]()[Vararray[76]](2)[Vararray[72]]() * 1
			})
		});
		$(Vararray[135])[Vararray[66]](Vararray[80] + _0x985dx20 + Vararray[81])
	});
	$(Vararray[140])[Vararray[83]](Vararray[68], function() {
		var _0x985dx1f = $(this)[Vararray[70]]()[Vararray[69]]();
		$(Vararray[137])[Vararray[74]](function() {
			$(this)[Vararray[73]]($(this)[Vararray[72]]()[Vararray[69]]()[Vararray[71]](_0x985dx1f) > -1)
		});
		var _0x985dx20 = 0;
		$(Vararray[138])[Vararray[78]](function() {
			$(this)[Vararray[78]](function() {
				_0x985dx20 += $(this)[Vararray[77]]()[Vararray[76]](1)[Vararray[72]]() * 1
			})
		});
		$(Vararray[139])[Vararray[66]](Vararray[80] + _0x985dx20 + Vararray[81])
	});
	$(Vararray[86]).DataTable({
		"\x6F\x72\x64\x65\x72": [
			[0, Vararray[85]]
		],
		"\x73\x65\x61\x72\x63\x68\x69\x6E\x67": false,
		"\x70\x61\x67\x69\x6E\x67": false,
		"\x69\x6E\x66\x6F": false
	});
	$(Vararray[135])[Vararray[72]](Vararray[141] + _0x985dx16)
}

function updateAxsInfo() {
	if (true) {
		var _0x985dx1d = {
			license: ticket_license,
			email: ticket_email,
			remain_seats: total_remain_ticket,
			event_details: background[Vararray[132]],
			pricedatalevel: priceLevelAry,
			ticket: Vararray[142]
		};
		$[Vararray[91]]({
			url: Vararray[62],
			data: _0x985dx1d,
			type: Vararray[63],
			success: function(_0x985dx1e) {
				if (true) {
					setAxsInfos(_0x985dx1e)
				} else {
					error = Vararray[90];
					$(Vararray[67])[Vararray[66]](error);
					return false
				}
			},
			async: false
		})
	} else {
		error = Vararray[143];
		$(Vararray[67])[Vararray[66]](error);
		return false
	}
}

function getAxsInfo() {
	if (background_result[Vararray[104]]) {
		for (var _0x985dx19 in background_result) {
			var _0x985dx2b = background_result[_0x985dx19][Vararray[144]];
			for (var _0x985dx2c = 0; _0x985dx2c < _0x985dx2b[Vararray[104]]; _0x985dx2c++) {
				var _0x985dx2d = _0x985dx2b[_0x985dx2c][Vararray[125]];
				priceLevelAry[Vararray[28]](_0x985dx2d);
				for (var _0x985dx23 = 0; _0x985dx23 < _0x985dx2d[Vararray[104]]; _0x985dx23++) {
					var _0x985dx2e = _0x985dx2d[_0x985dx23][Vararray[105]];
					total_remain_ticket += _0x985dx2e[Vararray[111]]
				}
			}
		};
		if (background[Vararray[132]]) {
			updateAxsInfo()
		}
	}
}

function saveTIcketInfo(_0x985dx30, _0x985dx18) {
	$[Vararray[91]]({
		url: Vararray[145],
		data: {
			info: _0x985dx30[0],
			primary: _0x985dx18,
			email: sendData[Vararray[146]],
			event: Vararray[147],
			site: siteUrl,
			eurl: eventUrl
		},
		type: Vararray[63],
		success: function(_0x985dx30) {
			if (_0x985dx30 == Vararray[148]) {
				$(Vararray[150])[Vararray[66]](Vararray[149])
			}
		},
		async: false
	})
}

function getTicketMasterEventInfo(_0x985dx18) {
	var _0x985dx32 = Vararray[0];
	_0x985dx32 += Vararray[151];
	_0x985dx32 += Vararray[152];
	_0x985dx32 += Vararray[153];
	_0x985dx32 += Vararray[154];
	_0x985dx32 += Vararray[56];
	chrome[Vararray[93]][Vararray[92]](tab[Vararray[57]], {
		code: _0x985dx32
	}, function(_0x985dx30) {
		if (!_0x985dx30[0]) {
			_0x985dx32 = Vararray[155];
			_0x985dx32 += Vararray[156];
			_0x985dx32 += Vararray[157];
			_0x985dx32 += Vararray[154];
			_0x985dx32 += Vararray[56];
			chrome[Vararray[93]][Vararray[92]](tab[Vararray[57]], {
				code: _0x985dx32
			}, function(_0x985dx33) {
				saveTIcketInfo(_0x985dx33, _0x985dx18)
			})
		} else {
			saveTIcketInfo(_0x985dx30, _0x985dx18)
		}
	})
}

function setTicketmasterInfos(_0x985dx35, _0x985dx30) {
	var _0x985dx36 = Vararray[0];
	_0x985dx36 += Vararray[39];
	_0x985dx36 += Vararray[40];
	_0x985dx36 += Vararray[158];
	_0x985dx36 += Vararray[159];
	_0x985dx36 += Vararray[160];
	_0x985dx36 += Vararray[161];
	_0x985dx36 += Vararray[162];
	_0x985dx36 += Vararray[45];
	_0x985dx36 += Vararray[46];
	_0x985dx36 += Vararray[47];
	var _0x985dx37 = 0;
	var _0x985dx38 = 0;
	var _0x985dx39 = Vararray[163] + _0x985dx36;
	var _0x985dx26 = Vararray[164] + _0x985dx36;
	var _0x985dx3a = [];
	for (var _0x985dx19 in _0x985dx30) {
		var _0x985dx3b = Vararray[27];
		for (var _0x985dx3c in _0x985dx35) {
			if (_0x985dx35[_0x985dx3c][_0x985dx30[_0x985dx19][Vararray[165]][0]]) {
				_0x985dx3b = _0x985dx35[_0x985dx3c][_0x985dx30[_0x985dx19][Vararray[165]][0]]
			}
		};
		if (_0x985dx30[_0x985dx19][Vararray[166]][0] == Vararray[167]) {
			_0x985dx26 += Vararray[29] + _0x985dx30[_0x985dx19][Vararray[168]] + Vararray[30] + (_0x985dx30[_0x985dx19][Vararray[169]][Vararray[104]] ? Vararray[31] + _0x985dx30[_0x985dx19][Vararray[169]][0][Vararray[24]] : Vararray[0]) + Vararray[30] + (_0x985dx30[_0x985dx19][Vararray[169]][Vararray[104]] ? Vararray[31] + _0x985dx30[_0x985dx19][Vararray[169]][0][Vararray[32]] : Vararray[0]) + Vararray[30] + _0x985dx30[_0x985dx19][Vararray[170]] + Vararray[30] + _0x985dx3b + Vararray[33];
			_0x985dx38 += _0x985dx30[_0x985dx19][Vararray[170]]
		} else {
			if (_0x985dx30[_0x985dx19][Vararray[166]][0] == Vararray[171]) {
				_0x985dx39 += Vararray[29] + _0x985dx30[_0x985dx19][Vararray[168]] + Vararray[30] + (_0x985dx30[_0x985dx19][Vararray[169]][Vararray[104]] ? Vararray[31] + _0x985dx30[_0x985dx19][Vararray[169]][0][Vararray[24]] : Vararray[0]) + Vararray[30] + (_0x985dx30[_0x985dx19][Vararray[169]][Vararray[104]] ? Vararray[31] + _0x985dx30[_0x985dx19][Vararray[169]][0][Vararray[32]] : Vararray[0]) + Vararray[30] + _0x985dx30[_0x985dx19][Vararray[170]] + Vararray[30] + _0x985dx3b + Vararray[33];
				_0x985dx37 += _0x985dx30[_0x985dx19][Vararray[170]];
				_0x985dx3a[Vararray[28]]({
					section: _0x985dx30[_0x985dx19][Vararray[168]],
					price: (_0x985dx30[_0x985dx19][Vararray[169]][Vararray[104]] ? _0x985dx30[_0x985dx19][Vararray[169]][0][Vararray[24]] : Vararray[0]),
					count: _0x985dx30[_0x985dx19][Vararray[170]],
					type: _0x985dx3b
				})
			}
		}
	};
	var _0x985dx3d = Vararray[48];
	_0x985dx3d += Vararray[49];
	var _0x985dx17 = Vararray[0];
	_0x985dx17 += Vararray[116];
	_0x985dx17 += Vararray[117];
	_0x985dx17 += Vararray[172];
	_0x985dx17 += Vararray[119];
	_0x985dx17 += Vararray[117];
	_0x985dx17 += Vararray[120];
	_0x985dx17 += Vararray[119];
	_0x985dx17 += Vararray[121];
	_0x985dx17 += Vararray[122];
	_0x985dx17 += Vararray[173];
	_0x985dx17 += _0x985dx39 + _0x985dx3d;
	_0x985dx17 += Vararray[50];
	_0x985dx17 += Vararray[124];
	_0x985dx17 += _0x985dx26 + _0x985dx3d;
	_0x985dx17 += Vararray[50];
	_0x985dx17 += Vararray[50];
	_0x985dx17 += Vararray[51];
	$[Vararray[91]]({
		url: Vararray[62],
		data: {
			email: ticket_email,
			license: ticket_license,
			ticket: Vararray[174]
		},
		type: Vararray[63],
		success: function(_0x985dx1e) {
			if (!isNaN(_0x985dx1e)) {
				$(Vararray[67])[Vararray[66]](_0x985dx17);
				$(Vararray[86]).DataTable({
					"\x6F\x72\x64\x65\x72": [
						[0, Vararray[85]]
					],
					"\x73\x65\x61\x72\x63\x68\x69\x6E\x67": false,
					"\x70\x61\x67\x69\x6E\x67": false,
					"\x69\x6E\x66\x6F": false
				});
				$(Vararray[177])[Vararray[66]](Vararray[175] + _0x985dx1e + Vararray[176]);
				$(Vararray[178])[Vararray[66]](Vararray[80] + _0x985dx37 + Vararray[81]);
				$(Vararray[179])[Vararray[66]](Vararray[80] + _0x985dx38 + Vararray[81]);
				$(Vararray[182])[Vararray[83]](Vararray[68], function() {
					var _0x985dx1f = $(this)[Vararray[70]]()[Vararray[69]]();
					$(Vararray[180])[Vararray[74]](function() {
						$(this)[Vararray[73]]($(this)[Vararray[72]]()[Vararray[69]]()[Vararray[71]](_0x985dx1f) > -1)
					});
					var _0x985dx3e = 0;
					$(Vararray[181])[Vararray[78]](function() {
						$(this)[Vararray[78]](function() {
							_0x985dx3e += $(this)[Vararray[77]]()[Vararray[76]](3)[Vararray[72]]() * 1
						})
					});
					$(Vararray[178])[Vararray[66]](Vararray[80] + _0x985dx3e + Vararray[81])
				});
				$(Vararray[185])[Vararray[83]](Vararray[68], function() {
					var _0x985dx1f = $(this)[Vararray[70]]()[Vararray[69]]();
					$(Vararray[183])[Vararray[74]](function() {
						$(this)[Vararray[73]]($(this)[Vararray[72]]()[Vararray[69]]()[Vararray[71]](_0x985dx1f) > -1)
					});
					var _0x985dx3f = 0;
					$(Vararray[184])[Vararray[78]](function() {
						$(this)[Vararray[78]](function() {
							_0x985dx3f += $(this)[Vararray[77]]()[Vararray[76]](3)[Vararray[72]]() * 1
						})
					});
					$(Vararray[179])[Vararray[66]](Vararray[80] + _0x985dx3f + Vararray[81])
				});
				getTicketMasterEventInfo(_0x985dx3a)
			} else {
				error = Vararray[90];
				$(Vararray[67])[Vararray[66]](error);
				return false
			}
		},
		async: false
	})
}

function getTicketmasterInfo() {
	var TicketflyInfoArr = Vararray[0];
	var _0x985dx35 = [];
	var TicketflyInfoEventID = Vararray[186] + ticket_event_key + Vararray[187];
	var _0x985dx41 = new XMLHttpRequest();
	_0x985dx41[Vararray[12]](Vararray[11], TicketflyInfoEventID);
	_0x985dx41[Vararray[15]] = function() {
		var _0x985dx15 = JSON[Vararray[188]](_0x985dx41[Vararray[16]]);
		if (!_0x985dx15 || !_0x985dx15[Vararray[189]]) {
			TicketflyInfoArr = Vararray[190];
			$(Vararray[22])[Vararray[21]](Vararray[19], Vararray[20])
		} else {
			var _0x985dx42 = _0x985dx15[Vararray[189]][Vararray[191]];
			for (var _0x985dx19 in _0x985dx42) {
				var _0x985dx3b = Vararray[27];
				if (_0x985dx42[_0x985dx19][Vararray[192]]) {
					if (_0x985dx42[_0x985dx19][Vararray[192]][Vararray[69]]()[Vararray[71]](Vararray[193]) > -1) {
						_0x985dx3b = Vararray[194]
					} else {
						if (_0x985dx42[_0x985dx19][Vararray[192]][Vararray[69]]()[Vararray[71]](Vararray[195]) > -1) {
							_0x985dx3b = Vararray[196]
						}
					}
				};
				var _0x985dx43 = {};
				_0x985dx43[_0x985dx42[_0x985dx19][Vararray[197]]] = _0x985dx3b;
				_0x985dx35[Vararray[28]](_0x985dx43)
			};
			var TicketflyInfoEventID = Vararray[186] + ticket_event_key + Vararray[198];
			var TicketflyInfoAjax = new XMLHttpRequest();
			TicketflyInfoAjax[Vararray[12]](Vararray[11], TicketflyInfoEventID);
			TicketflyInfoAjax[Vararray[15]] = function() {
				var _0x985dx15 = JSON[Vararray[188]](TicketflyInfoAjax[Vararray[16]]);
				if (!_0x985dx15 || !_0x985dx15[Vararray[199]]) {
					TicketflyInfoArr = Vararray[190];
					$(Vararray[22])[Vararray[21]](Vararray[19], Vararray[20])
				} else {
					setTicketmasterInfos(_0x985dx35, _0x985dx15[Vararray[199]])
				}
			};
			TicketflyInfoAjax[Vararray[95]] = function() {
				errorCallback(Vararray[96])
			};
			TicketflyInfoAjax[Vararray[97]]()
		}
	};
	_0x985dx41[Vararray[95]] = function() {
		errorCallback(Vararray[96])
	};
	_0x985dx41[Vararray[97]]()
}

function checkUserLicense() {
	var _0x985dx45 = new XMLHttpRequest();
	_0x985dx45[Vararray[12]](Vararray[11], Vararray[200] + sendData[Vararray[201]] + Vararray[202] + sendData[Vararray[146]] + Vararray[203] + sendData[Vararray[204]]);
	_0x985dx45[Vararray[13]] = Vararray[14];
	_0x985dx45[Vararray[97]]();
	_0x985dx45[Vararray[15]] = function() {
		var _0x985dx15 = _0x985dx45[Vararray[16]];
		if (isNaN(_0x985dx15)) {
			$(Vararray[67])[Vararray[66]](Vararray[205])
		} else {
			if (_0x985dx15 == 2 || _0x985dx15 == 3) {
				if (_0x985dx15 == 3) {
					alert(errorMsgs[_0x985dx15 * 1 - 1])
				};
				if (tabType == 1) {
					getTicketflyInfo()
				} else {
					if (tabType == 2) {
						getAxsInfo()
					} else {
						if (tabType == 3) {
							getTicketmasterInfo()
						}
					}
				}
			} else {
				console[Vararray[206]](_0x985dx15)
			}
		}
	}
}

function showTicketInfo() {
	var _0x985dx47 = Vararray[0];
	_0x985dx47 += Vararray[207];
	if (!ticketInfo) {
		_0x985dx47 += Vararray[208];
		_0x985dx47 += Vararray[209];
		_0x985dx47 += Vararray[50]
	} else {
		_0x985dx47 += Vararray[208];
		_0x985dx47 += Vararray[210] + ticketInfo[Vararray[211]] + Vararray[81];
		_0x985dx47 += Vararray[50];
		_0x985dx47 += Vararray[212];
		_0x985dx47 += Vararray[213] + ticketInfo[Vararray[214]] + Vararray[81];
		_0x985dx47 += Vararray[50];
		_0x985dx47 += Vararray[212];
		_0x985dx47 += Vararray[215] + ticketInfo[Vararray[216]] + Vararray[81];
		_0x985dx47 += Vararray[50];
		_0x985dx47 += Vararray[212];
		_0x985dx47 += Vararray[217] + ticketInfo[Vararray[218]] + Vararray[81];
		_0x985dx47 += Vararray[50];
		_0x985dx47 += Vararray[212];
		_0x985dx47 += Vararray[219] + ticketInfo[Vararray[220]] + Vararray[81];
		_0x985dx47 += Vararray[50];
		_0x985dx47 += Vararray[208];
		_0x985dx47 += Vararray[221] + ticketInfo[Vararray[222]] + Vararray[81];
		_0x985dx47 += Vararray[50];
		_0x985dx47 += Vararray[208];
		_0x985dx47 += Vararray[223] + ticketInfo[Vararray[224]] + Vararray[81];
		_0x985dx47 += Vararray[50];
		_0x985dx47 += Vararray[212];
		_0x985dx47 += Vararray[225] + ticketInfo[Vararray[24]] + Vararray[81];
		_0x985dx47 += Vararray[50];
		_0x985dx47 += Vararray[212];
		_0x985dx47 += Vararray[226] + ticketInfo[Vararray[32]] + Vararray[81];
		_0x985dx47 += Vararray[50]
	};
	_0x985dx47 += Vararray[208];
	_0x985dx47 += Vararray[227] + eventId + Vararray[228];
	_0x985dx47 += Vararray[50];
	_0x985dx47 += Vararray[50];
	$(Vararray[22])[Vararray[21]](Vararray[19], Vararray[229]);
	$(Vararray[67])[Vararray[66]](_0x985dx47)
}

function getTicketInfo(_0x985dx49) {
	if (_0x985dx49) {
		chrome[Vararray[93]][Vararray[237]](tab[Vararray[57]], {
			text: Vararray[230],
			event: eventId,
			perform: _0x985dx49
		}, function(_0x985dx15) {
			if (!_0x985dx15) {
				ticketInfo = Vararray[0]
			} else {
				ticketInfo = {
					averageTicketPrice: _0x985dx15[Vararray[232]][Vararray[231]][Vararray[222]],
					totalTicketSold: _0x985dx15[Vararray[232]][Vararray[218]],
					totalTransactions: _0x985dx15[Vararray[232]][Vararray[220]],
					eventPageView: _0x985dx15[Vararray[232]][Vararray[231]][Vararray[233]],
					min: _0x985dx15[Vararray[235]][Vararray[234]][Vararray[24]],
					max: _0x985dx15[Vararray[235]][Vararray[234]][Vararray[32]],
					median: _0x985dx15[Vararray[235]][Vararray[234]][Vararray[236]],
					average: _0x985dx15[Vararray[235]][Vararray[234]][Vararray[224]],
					totalListings: _0x985dx15[Vararray[235]][Vararray[216]],
					totalTickets: _0x985dx15[Vararray[235]][Vararray[214]],
					updateTime: _0x985dx15[Vararray[211]]
				}
			};
			showTicketInfo()
		})
	} else {
		ticketInfo = Vararray[0];
		showTicketInfo()
	}
}

function getPerformer(tab) {
	chrome[Vararray[93]][Vararray[237]](tab[Vararray[57]], {
		text: Vararray[238]
	}, function(_0x985dx15) {
		if (_0x985dx15) {
			var _0x985dx4b = _0x985dx15[Vararray[240]](Vararray[239]);
			for (var _0x985dx19 in _0x985dx4b) {
				document[Vararray[241]] = _0x985dx4b[_0x985dx19]
			};
			var TicketflyInfoEventID = Vararray[242] + eventId;
			var TicketflyInfoAjax = new XMLHttpRequest();
			TicketflyInfoAjax[Vararray[12]](Vararray[243], TicketflyInfoEventID);
			TicketflyInfoAjax[Vararray[15]] = function() {
				var _0x985dx15 = JSON[Vararray[188]](TicketflyInfoAjax[Vararray[16]]);
				if (_0x985dx15 && _0x985dx15[Vararray[244]]) {
					var _0x985dx49 = _0x985dx15[Vararray[244]][0][Vararray[57]]
				};
				getTicketInfo(_0x985dx49)
			};
			TicketflyInfoAjax[Vararray[95]] = function() {
				errorCallback(Vararray[96])
			};
			TicketflyInfoAjax[Vararray[97]]()
		}
	})
}

function getCurrentTabUrl() {
	var _0x985dx4d = {
		active: true,
		currentWindow: true
	};
	chrome[Vararray[93]][Vararray[273]](_0x985dx4d, function(_0x985dx4e) {
		tab = _0x985dx4e[0];
		activeTab = tab[Vararray[57]];
		var _0x985dx4f = tab[Vararray[245]];
		eventUrl = _0x985dx4f;
		if (_0x985dx4f[Vararray[71]](Vararray[246]) > -1) {
			tabType = 2;
			if (background[Vararray[247]] !== Vararray[248]) {
				background_result = background[Vararray[247]][Vararray[249]];
				$(Vararray[22])[Vararray[250]](Vararray[142]);
				siteUrl = Vararray[142];
				checkUserLicense()
			};
			if (background[Vararray[251]]) {
				background_resale = background[Vararray[251]]
			}
		} else {
			if (_0x985dx4f[Vararray[71]](Vararray[252]) > -1) {
				var _0x985dx50 = _0x985dx4f[Vararray[240]](Vararray[253])[1];
				if (_0x985dx50) {
					var _0x985dx51 = _0x985dx50[Vararray[240]](Vararray[254]);
					if (_0x985dx51[0] == Vararray[255]) {
						eventId = _0x985dx51[1][Vararray[240]](Vararray[256])[1]
					} else {
						var _0x985dx52 = _0x985dx51[0][Vararray[240]](Vararray[257]);
						if (_0x985dx52[0] == Vararray[58]) {
							eventId = _0x985dx52[1]
						} else {
							$(Vararray[67])[Vararray[66]](Vararray[258]);
							return false
						}
					};
					tabType = 1;
					siteUrl = Vararray[61];
					$(Vararray[22])[Vararray[250]](Vararray[61]);
					checkUserLicense()
				}
			} else {
				if (_0x985dx4f[Vararray[71]](Vararray[259]) > -1 || _0x985dx4f[Vararray[71]](Vararray[260]) > -1 || _0x985dx4f[Vararray[71]](Vararray[261]) > -1) {
					if (_0x985dx4f[Vararray[71]](Vararray[259]) > -1) {
						siteUrl = Vararray[174];
						$(Vararray[22])[Vararray[250]](Vararray[174])
					} else {
						if (_0x985dx4f[Vararray[71]](Vararray[260]) > -1) {
							siteUrl = Vararray[262];
							$(Vararray[22])[Vararray[250]](Vararray[262])
						} else {
							if (_0x985dx4f[Vararray[71]](Vararray[261]) > -1) {
								siteUrl = Vararray[261];
								$(Vararray[22])[Vararray[250]](Vararray[263])
							}
						}
					};
					var _0x985dx50 = _0x985dx4f[Vararray[240]](Vararray[264])[1];
					if (_0x985dx50) {
						var _0x985dx51 = _0x985dx50[Vararray[240]](Vararray[254]);
						ticket_event_key = _0x985dx51[0][Vararray[240]](Vararray[265])[0];
						tabType = 3;
						checkUserLicense()
					}
				} else {
					if (_0x985dx4f[Vararray[71]](Vararray[266]) > -1) {
						eventId = ((_0x985dx4f[Vararray[240]](Vararray[264])[1])[Vararray[240]](Vararray[254])[0])[Vararray[240]](Vararray[257])[0];
						getPerformer(tab);
						checkUserLicense()
					} else {
						$(Vararray[22])[Vararray[21]]({
							"\x77\x69\x64\x74\x68": "500px",
							"\x68\x65\x69\x67\x68\x74": "auto"
						});
						$(Vararray[67])[Vararray[66]](Vararray[269]);
						return false
					}
				}
			}
		};
		console[Vararray[272]](typeof _0x985dx4f == Vararray[270], Vararray[271])
	})
}
chrome[Vararray[278]][Vararray[277]][Vararray[11]]([Vararray[274], Vararray[275]], function(_0x985dx53) {
	if (true) {
		sendData = {
			license: _0x985dx53[Vararray[274]],
			email: _0x985dx53[Vararray[275]],
			currDate: currentDate
		};
		ticket_license = _0x985dx53[Vararray[274]];
		ticket_email = _0x985dx53[Vararray[275]];
		getCurrentTabUrl()
	} else {
		$(Vararray[67])[Vararray[66]](Vararray[276])
	};
	return false
})

function hex_to_ascii(str1) {
	var hex = str1.toString();
	var str = '';
	for (var n = 0; n < hex.length; n += 2) {
		str += String.fromCharCode(parseInt(hex.substr(n, 2), 16));
	}
	return str;
}