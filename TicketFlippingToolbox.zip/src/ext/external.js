//env="Dev";
env="Prod";
//apiUrl  = "https://i7bq3ya4sj.execute-api.us-west-1.amazonaws.com/prod/getTixxCEJS?v="+chrome.runtime.getManifest().version+"&"
apiUrl = 'https://flare.ticketflipping.com/api/tft/getinfo?v=' + chrome.runtime.getManifest().version + '&';
redirectUri=location.href;
code="";
if (typeof(redirectUri)!="undefined") {
    i=redirectUri.indexOf("code=");
    if (i>0) {
    code=redirectUri.substr(i+5);
    i=code.indexOf("&");
    if (i>0) {
        code=code.substr(0,i);
    }
    }
}

if (code!="") {
    $.getJSON(apiUrl+"&env="+env+"&code="+code, function(data) {
      token=data.text;
      console.log(token)
      chrome.runtime.sendMessage({type:"setSlackToken", slackToken: token}, null, function () {});
      window.setTimeout(function() {
          chrome.runtime.sendMessage({type:"initMonitoring"}, null, function () {});
      }, 1000)
      window.close()
    });
}
